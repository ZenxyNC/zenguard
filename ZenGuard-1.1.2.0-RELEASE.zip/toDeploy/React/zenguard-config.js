//DO NOT MODIFY THIS FILE!
//Modifying this file will affect the engine.

export const _conf =
  {
    name : "ZenGuard Protocol",
    version : "1.1.2.0",
    development : "RELEASE",
    engine_version : "1.1.3.0",
    engine_type : "module",
    engine_context : "ReactJS",
  }
