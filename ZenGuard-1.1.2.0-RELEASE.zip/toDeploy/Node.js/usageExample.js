const prompt = require("prompt-sync")({ sigint : true }); //Unecessary module. This will not affecting the security protocol


const loginProcessor = require('./loginProcessor'); //Import the module.

var _name = "Jane Doe";
var _password = "JaneDoe123";

const userLogin = new loginProcessor(_name, _password)
userLogin.startEngine()