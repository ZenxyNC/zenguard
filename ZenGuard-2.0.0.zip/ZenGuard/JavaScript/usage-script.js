// IMPORTANT — Import the hashProcessor
import hashProcessor from "./hashProcessor.js";

// This is your script. You can make your own handler, but make sure to apple the ZenGuard usage correctly.
document.getElementById("button").addEventListener("click", () => {
  console.log(document.getElementById("input").value);


  // ZenGuard Usage
  const processor = new hashProcessor(document.getElementById("input").value);
  const startengine = processor.startengine();
  // The start engine will return an object with two properties: ok and object.
  // The ok property is a boolean that indicates whether the process was successful.
  // The object property is the result of the process.


  document.getElementById("result").innerHTML = `{ok: ${startengine.ok}, object: ${startengine.object}}`;
});

