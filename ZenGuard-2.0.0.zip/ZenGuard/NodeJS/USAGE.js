const hashProcessor = require("./hashProcessor");

const myString = "ZenGuard"
const prehashedString = "^&*-_!@$%^@&.?!=/`~!@/`~!#$()+=[]_+=[]{>?/`~"

const processor = new hashProcessor(myString);
const startengine = processor.startengine();

console.log(startengine);