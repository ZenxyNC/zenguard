from hashMap import _hash

class hashProcessor:
  # Initialize Local Variable (String)
  def __init__(self, string, minimumLength=5):
    self.string = string
    self.minimumLength = minimumLength
    self.__hashedString = ""

  def response(self, ok, object):
    return {"ok": ok, "object": object}
  

  # Main function to start hash process.
  def startengine(self):
    # It should be engine verification process, but i haven't finished the system yet.

    # ======== Check String Requirements ========
    validString = self.checkString()

    # Catch validation response
    if (not validString["ok"]):
      return self.response(False, validString["object"]) # Return response (NOT OK)
    # If validation is OK, continue to hash process

    # ======== Hash String ========

    hashProcess = self.hashString()

    # Catch hash response
    if (not hashProcess["ok"]):
      return self.response(False, hashProcess["object"]) # Return response (NOT OK)

    return self.response(True, self.__hashedString) # Return response (OK)
    
  
  # Function to check string requirements
  def checkString(self):

    # Check empty string or whitespace
    if (self.string == "" or self.string.strip() == ""):
      return self.response(False, "String is empty or whitespace.") # Return response (NOT OK)

    # Check string length
    if (len(self.string) < self.minimumLength):
      return self.response(False, "String length must be at least 5 characters.") # Return response (NOT OK)

    return self.response(True, "String is valid.") # Return response (OK)
  


  # Function to hash string
  def hashString(self):
    splitString = list(self.string) # Split string into individual characters in a list.

    # Loop through each character in the list
    for char in splitString:
      # Check if character is in the hash map
      if (char in _hash):
        # Replace character with its hash code
        splitString[splitString.index(char)] = _hash[char]
    
    # Join the list into a string, then put it in the hashedString variable
    self.__hashedString = "".join(splitString)
    return self.response(True, "String is hashed.") # Return response (OK)
      
    

  
