from hashProcessor import hashProcessor

myString = "ZenGuard" # String to be hashed
prehashedString = '^&*-_!@$%^@&.?!=/`~!@/`~!#$()+=[]_+=[]{>?/`~' # Hash of "ZenGuard"

hashProcessor = hashProcessor(myString) # Initialize hashProcessor
startEngine = hashProcessor.startengine() # Start hash process

# Check if hash process is successful
if(startEngine["ok"]): 
  # Check if hash result is equal to prehashed string
  if(prehashedString == startEngine["object"]):
    print("Prehashed string is correct and hash result is matched.")
  else:
    print("String is hashed, but not match the prehashed string.")
else:
  print(startEngine["object"])