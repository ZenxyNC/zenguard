import processor from "./zenguard/loginProcessor.js";

const submitButton = document.getElementById("submit");

submitButton.addEventListener("click", async () => {
  const userid = document.getElementById("userid-input").value;
  const password = document.getElementById("password-input").value;

  const userLoginProcessor = new processor(userid, password);
  const userLogin = await userLoginProcessor.startEngine()
  document.getElementById("acikiwir").innerHTML = JSON.stringify(userLogin);
  console.log(userLogin)
  if(userLogin.status === "OK") {
    alert("Yeyy, login berhasil")
  }
})