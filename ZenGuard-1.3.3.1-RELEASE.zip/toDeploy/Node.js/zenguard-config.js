//DO NOT MODIFY THIS FILE!
//Modifying this file will affect the engine.

const _conf =
  {
    name : "ZenGuard Protocol",
    version : "1.3.3.1",
    development : "RELEASE",
    engine_version : "1.3.4.1",
    engine_type : "module",
    engine_context : "NodeJS",
  }

module.exports = _conf