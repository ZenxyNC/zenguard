import _ASSETS from "./loginAssets";  // Login assets
import _hash from "./loginHasher";  // Login hasher
import config from "./zenguard-config.js";

// Fetch configuration from GitHub
async function fetchConfig() {
  try {
    const response = await fetch("https://raw.githubusercontent.com/zenxync/zenguard/main/public/zenguard-config-reactjs.json");
    if (!response.ok) throw new Error("Failed to fetch ZenGuard configuration.");
    return await response.json();
  } catch (error) {
    console.error(error.message);
    return null;
  }
}

class processor {
  #hashedPassword;

  //You can change this based on your needs.
  name; 
  #password;

  //Don't forget to change the constructor also.
  constructor(name, password) {
    this.name = name;
    this.#password = password;
  }

  //startEngine is the MAIN FUNCTION. 
  async startEngine() {
    const engineVerifying = await this.verifyEngine();
    
    if (engineVerifying?.isVerified) {
      console.log("Process started.");
      console.log("Finding local-saved info..");
      try {
        const localDefiner = localStorage.getItem("zenguard-protocol-logininfo_secured");
        if (localDefiner) {
          const parsedData = JSON.parse(localDefiner);
          this.name = parsedData.name;
          this.#hashedPassword = parsedData.password_hashed;
        } else {
          this.hash();
        }
      } catch (error) {
        console.log("Auto-fetch failed. Continuing to do non-autofetch protocol.");
        this.hash();
      }
      const doVerify = this.verify();
      return doVerify

    } else {
      console.error("Login process aborted.");
      console.warn(engineVerifying?.message);
    }
  }

  hash() {
    if (this.#password) {
      let slicedPassword = this.#password.split("");
      console.log("Starting hashing process..");
      for (let i = 0; i < slicedPassword.length; i++) {
        if (_hash[slicedPassword[i]]) {
          slicedPassword[i] = _hash[slicedPassword[i]];
        }
      }

      console.log("Hash success.");
      this.#hashedPassword = slicedPassword.join("");
      this.verify();
    }
  }

  verify() {
    try {
      if (this.#hashedPassword) {
        if (this.name in _ASSETS) {
          const userPassword = _ASSETS[this.name].credentials.password;
          if (this.#hashedPassword === userPassword) {
            console.info("Login success.");
            return this.sendResponse("OK", { name : this.name, password : this.#hashedPassword })
            
            //You can put a save info feature by calling "this.saveInfo()"
  
          } else {
            throw new Error("Password not match.");
          }
        } else {
          throw new Error("User is not in database.");
        }
      } else {
        throw new Error("Password is unreadable.");
      }
    } catch(err) {
      return this.sendResponse("FAIL", err.message)
    }
  }
  
  sendResponse(status, object) {
    return { status : status, message : object }
  }


  saveInfo() {
    //Put the data you want to save locally.
    const toSave = JSON.stringify({
      name: this.name,
      password_hashed: this.#hashedPassword
    });

    try {
      localStorage.setItem("zenguard-protocol-logininfo_secured", toSave);
    } catch (error) {
      console.log(error);
      console.log("Info saving is failed. No data saved.");
    }
  }

  async verifyEngine() {
    try {
      const remoteConf = await fetchConfig();
      if (!remoteConf) throw new Error("Failed to fetch remote configuration.");

      if (config.version !== remoteConf.version) {
        throw new Error("Local ZenGuard version is invalid or outdated.");
      } else if (config.engine_version !== remoteConf.engine_version) {
        throw new Error("Local ZenGuard Engine version is invalid or outdated.");
      } else if (config.engine_context !== remoteConf.engine_context || config.name !== remoteConf.name) {
        throw new Error("Local Zenguard configuration cannot be verified.");
      }

      return { isVerified: true };
    } catch (err) {
      return { isVerified: false, message: err.message };
    }
  }
}

export default processor;
