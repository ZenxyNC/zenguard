var prompt = require("prompt-sync")({ sigint : true });


function _0x3a4a(){var _0x12e9cb=['36pyxRRe','9722HWOQmj','^,|)!','#&~[]','=<|;,','$)[.>{[','~|;|^}','%[=;^!)','@!<@@\x27',';}|?*>$','/,/|&=\x27','=::%,^','>(>{}\x27','<<[[*!)','#_|*{<','}\x27\x27:#','$}?:%{>','$%)./%\x27','^,@+;','<~<][^','|^()@,','{,>,\x27#','\x27%]/{','+/$&#','@*_{!@','=|_`~.','*-~\x27*','3025028BWsPuS','%&@*$','256376PcGCgs','4399056yeLpRn','.\x27:\x27&(','+\x27,(&','!](??%','37966730hAhbrk','~;<(}|?','5ylpuuR','?(@`$','|=#]&','</)[@','{,|_=/?','(:~_(;','$[^)|','?*#%;','|*_^)/','14RziOiU','$~!+\x27.','+}^(|','+=,!&',',*^.$&','|##>`=','10136634YjDNNP','^<|&;','327171aCYEsJ','}@-/#]>','%}(`>','/<|+(:','%@:&)',':?,=*('];_0x3a4a=function(){return _0x12e9cb;};return _0x3a4a();}var _0x181991=_0x5d7a;(function(_0x30fb89,_0x4d8544){var _0x1f29d6=_0x5d7a,_0x12f547=_0x30fb89();while(!![]){try{var _0x476af0=-parseInt(_0x1f29d6(0xf0))/0x1*(-parseInt(_0x1f29d6(0xf1))/0x2)+-parseInt(_0x1f29d6(0xea))/0x3+parseInt(_0x1f29d6(0xd0))/0x4*(-parseInt(_0x1f29d6(0xd9))/0x5)+-parseInt(_0x1f29d6(0xe8))/0x6+parseInt(_0x1f29d6(0xe2))/0x7*(-parseInt(_0x1f29d6(0xd2))/0x8)+-parseInt(_0x1f29d6(0xd3))/0x9+parseInt(_0x1f29d6(0xd7))/0xa;if(_0x476af0===_0x4d8544)break;else _0x12f547['push'](_0x12f547['shift']());}catch(_0x12738f){_0x12f547['push'](_0x12f547['shift']());}}}(_0x3a4a,0xd2f26));function _0x5d7a(_0x58a5e7,_0x1dd51f){var _0x3a4a93=_0x3a4a();return _0x5d7a=function(_0x5d7a63,_0x3f5414){_0x5d7a63=_0x5d7a63-0xb8;var _0x4bcd73=_0x3a4a93[_0x5d7a63];return _0x4bcd73;},_0x5d7a(_0x58a5e7,_0x1dd51f);}var mapping={'0':_0x181991(0xdc),'1':'&{))!_','2':_0x181991(0xc8),'3':_0x181991(0xe9),'4':_0x181991(0xbc),'5':_0x181991(0xe0),'6':']])~:','7':_0x181991(0xb9),'8':_0x181991(0xed),'9':_0x181991(0xe1),'A':_0x181991(0xe4),'B':_0x181991(0xe7),'C':_0x181991(0xca),'D':'(^!\x27|,<','E':_0x181991(0xdf),'F':_0x181991(0xc1),'G':_0x181991(0xdb),'H':_0x181991(0xbd),'I':'&(~]&;','J':_0x181991(0xcf),'K':_0x181991(0xf2),'L':'?_?$!.','M':_0x181991(0xc7),'N':_0x181991(0xc9),'O':_0x181991(0xc0),'P':_0x181991(0xd6),'Q':'%|.`[*`','R':_0x181991(0xc6),'S':_0x181991(0xd4),'T':'`:{?[.!','U':_0x181991(0xc5),'V':_0x181991(0xcb),'W':_0x181991(0xba),'X':_0x181991(0xbe),'Y':_0x181991(0xbf),'Z':_0x181991(0xec),'a':_0x181991(0xd5),'b':'^?^{^_','c':_0x181991(0xce),'d':_0x181991(0xe3),'e':_0x181991(0xda),'f':_0x181991(0xb8),'g':_0x181991(0xc4),'h':_0x181991(0xde),'i':']|^@?.','j':_0x181991(0xeb),'k':'@<<,],','l':_0x181991(0xbb),'m':_0x181991(0xcc),'n':_0x181991(0xee),'o':'+`(*:','p':_0x181991(0xe6),'q':_0x181991(0xdd),'r':_0x181991(0xef),'s':'^--;}','t':_0x181991(0xd8),'u':'-,$;[=','v':',-!,[','w':'}#.-~','x':_0x181991(0xc2),'y':_0x181991(0xe5),'z':_0x181991(0xc3),'@':_0x181991(0xcd),'_':_0x181991(0xd1),'*':'~^#$','&':'#($@&'};

function translatePassword(password) {
  let slicedPassword = password.split("");
  
  for(let i = 0; i < slicedPassword.length; i++) {
    if(mapping[slicedPassword[i]]) {
      slicedPassword[i] = mapping[slicedPassword[i]]
    } else {

    }
  }

  return slicedPassword.join("")
}

/*function getLength() {
  return Math.floor(Math.random() * (5 - 3 + 1)) + 5
}*/

console.log("Enter your password. \nType .finish to exit.")

while (true) {
  var rawPassword = prompt("Password : ").trim();
  if(!rawPassword) {
    console.error("There's nothing to translate. Password cannot be blank.")
  } else {
    if(rawPassword === ".finish") {
      break
    } else {
      console.log("Type .finish to exit.")
      console.log(`Translated password : \n${translatePassword(rawPassword)}`)
    }
  }
}
