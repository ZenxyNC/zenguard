//This file is including user data.

const _ASSETS = {
  //This is where the data placed.

  "John Doe" : {
    //Here you can make your own info category, for example we'll create "credentials" for private information and "personal" for personal information.

    credentials : {
      password : "*-~'*+`(*:(:~_(;%@:&)(^!'|,<+`(*:?(@`$&{))!_<~<][^^<|&;" //Password : JohnDoe123
    },

    personal : {
      username : "John",
      gender : "male",
      handsomeness : 57,
      age : 43
    }
  }
}

module.exports = _ASSETS