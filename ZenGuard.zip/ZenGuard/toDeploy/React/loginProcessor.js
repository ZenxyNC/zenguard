//import all necessary needs
import { _ASSETS } from "./loginAssets"; //Login assets
import { _hash } from "./loginHasher"; //Login hasher

class processor {
  name
  #password;
  #hashedPassword

  constructor(name, password) {
    this.name = name;
    this.#password = password;
  }

  startEngine() {
    console.log("Process started.")
    console.log("Finding local-saved info..")
    try {
      const localDefiner = localStorage.getItem("zenguard-protocol-logininfo_secured")
      if(localDefiner) {
        this.name = JSON.parse(localDefiner).name
        this.#hashedPassword = JSON.parse(localDefiner).password_hashed
      } else {
        this.hash()
      }
    } catch(error) {
      console.log("Auto-fetch is failed. Continuing to do non-autofetch protocol.");
      this.hash()
    }
  }

  hash() {
    if(this.#password) {
      let slicedPassword = this.#password.split("");
      console.log("Starting hashing process..")
      for(let i = 0; i < slicedPassword.length; i++) {
        if(_hash[slicedPassword[i]]) {
          slicedPassword[i] = _hash[slicedPassword[i]];
        } else {
  
        }
  
      }

      console.log("Hash success.")
      this.#hashedPassword = slicedPassword.join("");
      this.verify()
    }
  }

  verify() {
    if(this.#hashedPassword) {
      if(this.name in _ASSETS) {
        const userPassword = _ASSETS[this.name].credentials.password;
        if(this.#hashedPassword === userPassword) {
          console.info("Login success")
          console.log(`Name : ${this.name}, Password : ${this.#hashedPassword}`)
          return true
        }
      } else {
        console.error("User is not in database.")
        return false
      }
    } else {
      console.error("Password is unreadble.")
      return false
    }
  }

  saveInfo() {
    const toSave = JSON.stringify({
      name : this.name,
      password_hashed : this.#hashedPassword
    })
    try {
      localStorage.setItem("zenguard-protocol-logininfo_secured", toSave)
    } catch(error) {
      console.log(error)
      console.log("Info saving process failed. No data saved.");
    }
  }
}

const loginProcessor = new processor("John Doe", "JohnDoe123")
loginProcessor.startEngine()