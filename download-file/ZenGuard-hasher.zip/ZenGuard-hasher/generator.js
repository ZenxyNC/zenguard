function getLength() {
    return Math.floor(Math.random() * (5 - 3 + 1)) + 5
}

var mapping = {
    '0': '</)[@',
    '1': '&{))!_',
    '2': '<~<][^',
    '3': '^<|&;',
    '4': '%[=;^!)',
    '5': '?*#%;',
    '6': ']])~:',
    '7': '=<|;,',
    '8': '/<|+(:',
    '9': '|*_^)/',
    "A": '+}^(|',
    "B": '|##>`=',
    "C": "{,>,'#",
    "D": "(^!'|,<",
    "E": '$[^)|',
    "F": ">(>{}'",
    "G": '|=#]&',
    "H": "@!<@@'",
    "I": '&(~]&;',
    "J": "*-~'*",
    "K": '^,|)!',
    "L": '?_?$!.',
    "M": '^,@+;',
    "N": '|^()@,',
    "O": '=::%,^',
    "P": '!](??%',
    "Q": '%|.`[*`',
    "R": "$%)./%'",
    "S": ".':'&(",
    "T": '`:{?[.!',
    "U": '$}?:%{>',
    "V": "'%]/{",
    "W": '$)[.>{[',
    "X": ';}|?*>$',
    "Y": "/,/|&='",
    "Z": '%}(`>',
    "a": "+',(&",
    "b": '^?^{^_',
    "c": '=|_`~.',
    "d": "$~!+'.",
    "e": '?(@`$',
    "f": '#&~[]',
    "g": "}'':#",
    "h": '(:~_(;',
    "i": ']|^@?.',
    "j": '}@-/#]>',
    "k": '@<<,],',
    "l": '~|;|^}',
    "m": '+/$&#',
    "n": '%@:&)',
    "o": '+`(*:',
    "p": ',*^.$&',
    "q": '{,|_=/?',
    "r": ':?,=*(',
    "s": '^--;}',
    "t": '~;<(}|?',
    "u": '-,$;[=',
    "v": ',-!,[',
    "w": '}#.-~',
    "x": '<<[[*!)',
    "y": '+=,!&',
    "z": '#_|*{<',
    "@": "@*_{!@",
    "_": "%&@*$",
    "*" : "~^#$",
    "&": "#($@&"
}

var myPassword = "L!am@2025#C@rter!"
function translatePassword(password) {
    let slicedPassword = password.split("");
    
    for(let i = 0; i < slicedPassword.length; i++) {
        if(mapping[slicedPassword[i]]) {
            slicedPassword[i] = mapping[slicedPassword[i]]
        } else {

        }
    }

    return slicedPassword
}


// Translate the password
var translatedPassword = translatePassword(myPassword);

console.log("Original:", myPassword);
console.log("Translated:", translatedPassword.join(""));
