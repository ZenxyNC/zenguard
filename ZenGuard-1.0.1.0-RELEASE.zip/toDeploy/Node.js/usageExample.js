const prompt = require("prompt-sync")({ sigint : true }); //Unecessary module. This will not affecting the security protocol


const loginProcessor = require('./loginProcessor'); //Import the module.

var _name = "Jane Doe";
var _password = "JaneDoe123";

while(true) {
  console.log('Type .start to simulate, or .finish to exit.')
  var cmd = prompt("Action : ")
  if(cmd === ".start") {
    _name = prompt("Name : ");
    _password = prompt("Password : ", { echo : "*"});
    new loginProcessor(_name, _password).startEngine();

  } else {
    break
  }
}
