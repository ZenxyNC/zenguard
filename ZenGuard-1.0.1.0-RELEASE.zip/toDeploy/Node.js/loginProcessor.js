const prompt = require("prompt-sync")({ sigint : true }) //This line is removeable. Make sure you remove the function totally (Declarator and caller)

//import all necessary needs
const _ASSETS = require("./loginAssets"); // Login assets
const _hash = require("./loginHasher");  // Login hasher

class processor {
  #hashedPassword;

  //You can change this based on yuor needs.
  name; 
  #password;
  //Don't forget to change the constructor also.
  constructor(name, password) {
    this.name = name;
    this.#password = password;
  }

  //startEngine is the MAIN FUNCTION. 
  startEngine() {
    const engineVerifying = this.verifyEngine()
    if(engineVerifying.isVerified === true) {
      console.log("Process started.")
      console.log("Finding local-saved info..")
      try {
        const localDefiner = localStorage.getItem("zenguard-protocol-logininfo_secured")
        if(localDefiner) {
          this.name = JSON.parse(localDefiner).name
          this.#hashedPassword = JSON.parse(localDefiner).password_hashed
        } else {
          this.hash()
        }
      } catch(error) {
        console.log("Auto-fetch failed. Continuing to do non-autofetch protocol.");
        this.hash()
      }
    } else {
      console.error("Login process aborted.")
      console.warn(engineVerifying.message)
    }
  }

  hash() {
    if(this.#password) {
      let slicedPassword = this.#password.split("");
      console.log("Starting hashing process..")
      for(let i = 0; i < slicedPassword.length; i++) {
        if(_hash[slicedPassword[i]]) {
          slicedPassword[i] = _hash[slicedPassword[i]];
        } else {
  
        }
  
      }

      console.log("Hash success.")
      this.#hashedPassword = slicedPassword.join("");
      this.verify()
    }
  }

  verify() {
    if(this.#hashedPassword) {
      if(this.name in _ASSETS) {
        const userPassword = _ASSETS[this.name].credentials.password;
        if(this.#hashedPassword === userPassword) {
          console.info("Login success.")
          console.log(`Name : ${this.name}, Password : ${this.#hashedPassword}`)

          //This is unecessary property, you can remove it safely.
          /*const confirmSaving = prompt("Do you wish to save the information?[y/n]");
          if(confirmSaving.toLowerCase() === "y") {
            console.log("Info saved.")
            this.saveInfo()
          } else {
            console.log("Info not saved.")
          }*/

        } else {
          console.error("Password not match.")
        }
      } else {
        console.error("User is not in database.")
      }
    } else {
      console.error("Password is unreadble.")
    }
  }

  saveInfo() {
    //Put the data you want to save locally.
    const toSave = JSON.stringify({
      name : this.name,
      password_hashed : this.#hashedPassword
    })
    try {
      localStorage.setItem("zenguard-protocol-logininfo_secured", toSave)
    } catch(error) {
      console.log(error)
      console.log("Info saving is failed. No data saved.");
    }
  }

  verifyEngine() {
    try {
      const _conf = require("./zenguard-config")
      if(_conf["name"] === "ZenGuard Protocol") {
        if(_conf["version"] === "1.0.1.0") {
          if(_conf["engine_version"] === "1.0.2.0") {
            if(_conf["engine_context"] === "JavaScript") {
              return {
                isVerified : true,
              }
            } else {
              throw new Error("ZenGuard Engine cannot verify this configuration.");
            }
          } else {
            throw new Error("This ZenGuard engine version is not valid or outdated.");
          }
        } else {
          throw new Error("ZenGuard version is not valid or outdated.")
        }
      } else {
        throw new Error("ZenGuard Engine cannot verify this configuration.")
      }
    } catch(err) {
      return {
        isVerified : false,
        message : err.message
      }
    }
  }
}

module.exports = processor